import React from 'react'

const NotFound = () => {
  return (
    <div>NotFound-404 !!!!</div>
  )
}

export default NotFound